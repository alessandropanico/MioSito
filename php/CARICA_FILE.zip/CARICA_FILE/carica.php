<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_FILES["photo"]) && $_FILES["photo"]["error"] == 0) {
        $estensioniPermesse = 
        array("jpg" => "image/jpg", "jpeg" => "image/jpeg", "gif" => "image/gif", "png" => "image/png", "pdf" => "image/pdf");
        $nomeFile = $_FILES["photo"]["name"];
        $tipoFile = $_FILES["photo"]["type"];
        $dimensioneFile = $_FILES["photo"]["size"];
        $tempFile = $_FILES["photo"]["tmp_name"];
        $cartellaDestinazione = "immagini/";

        // Verifica se il tipo di file è consentito
        if (array_key_exists(pathinfo($nomeFile, PATHINFO_EXTENSION), $estensioniPermesse)) {
            // Verifica la dimensione del file (massimo 5 MB)
            if ($dimensioneFile <= 5 * 1024 * 1024) {
                // Verifica se il file con lo stesso nome esiste già
                if (file_exists($cartellaDestinazione . $nomeFile)) {
                    echo "Il file con lo stesso nome esiste già.";
                } else {
                    // Salva il file nella cartella "immagini" con il nome originale
                    move_uploaded_file($tempFile, $cartellaDestinazione . $nomeFile);
                    echo "Il file è stato caricato con successo con il nome: " . $nomeFile;
                }
            } else {
                echo "Il file è troppo grande. Massima dimensione consentita: 5 MB.";
            }
        } else {
            echo "Sono consentiti solo file di tipo JPEG, JPG, GIF, PNG.";
        }
    } else {
        echo "Errore nel caricamento del file. Assicurati di selezionare un file valido.";
    }
}
?>
