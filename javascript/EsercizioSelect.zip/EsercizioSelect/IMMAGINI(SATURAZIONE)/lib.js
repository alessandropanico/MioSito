function showImage() {
    let mostrafoto = document.getElementById("select").value;

    if ("select" != null) {
        document.getElementById("eva01").style.display = "none"
        document.getElementById("eva02").style.display = "none"
        document.getElementById("eva00").style.display = "none"

        document.getElementById(mostrafoto).style.display = "block"
    }
}


//CONTRASTO, SATURAZIONE, LUMINOSITA' 

const img = document.querySelector('.eva01');
const saturazioneInput = document.querySelector('#saturazione01');
const contrastoInput = document.querySelector('#contrasto01');
const luminositaInput = document.querySelector('#luminosita01');

saturazioneInput.addEventListener('input', () => {
  const saturazione = saturazioneInput.value;
  img.style.filter = `saturate(${saturazione}%) contrast(${contrastoInput.value}%) brightness(${luminositaInput.value}%)`;
});

contrastoInput.addEventListener('input', () => {
  const contrasto = contrastoInput.value;
  img.style.filter = `saturate(${saturazioneInput.value}%) contrast(${contrasto}%) brightness(${luminositaInput.value}%)`;
});

luminositaInput.addEventListener('input', () => {
  const luminosita = luminositaInput.value;
  img.style.filter = `saturate(${saturazioneInput.value}%) contrast(${contrastoInput.value}%) brightness(${luminosita}%)`;
});


//------------------------


const img2 = document.querySelector('.eva02');
const saturazioneInput2 = document.querySelector('#saturazione02');
const contrastoInput2 = document.querySelector('#contrasto02');
const luminositaInput2 = document.querySelector('#luminosita02');

saturazioneInput2.addEventListener('input', () => {
  const saturazione2 = saturazioneInput2.value;
  img2.style.filter = `saturate(${saturazione2}%) contrast(${contrastoInput2.value}%) brightness(${luminositaInput2.value}%)`;
});

contrastoInput2.addEventListener('input', () => {
  const contrasto2 = contrastoInput2.value;
  img2.style.filter = `saturate(${saturazioneInput2.value}%) contrast(${contrasto2}%) brightness(${luminositaInput2.value}%)`;
});

luminositaInput2.addEventListener('input', () => {
  const luminosita2 = luminositaInput2.value;
  img2.style.filter = `saturate(${saturazioneInput2.value}%) contrast(${contrastoInput2.value}%) brightness(${luminosita2}%)`;
});


//------------------------


const img0 = document.querySelector('.eva00');
const saturazioneInput0 = document.querySelector('#saturazione00');
const contrastoInput0 = document.querySelector('#contrasto00');
const luminositaInput0 = document.querySelector('#luminosita00');

saturazioneInput0.addEventListener('input', () => {
  const saturazione0 = saturazioneInput0.value;
  img0.style.filter = `saturate(${saturazione0}%) contrast(${contrastoInput0.value}%) brightness(${luminositaInput0.value}%)`;
});

contrastoInput0.addEventListener('input', () => {
  const contrasto0 = contrastoInput0.value;
  img0.style.filter = `saturate(${saturazioneInput0.value}%) contrast(${contrasto0}%) brightness(${luminositaInput0.value}%)`;
});

luminositaInput0.addEventListener('input', () => {
  const luminosita0 = luminositaInput0.value;
  img0.style.filter = `saturate(${saturazioneInput0.value}%) contrast(${contrastoInput0.value}%) brightness(${luminosita0}%)`;
});