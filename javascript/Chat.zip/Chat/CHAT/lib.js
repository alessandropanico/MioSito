const person1Input = document.getElementById("person1Input");
const person2Input = document.getElementById("person2Input");
const chatOutput = document.getElementById("chatOutput");

person1Input.addEventListener("keydown", function (event) {
  
  if (event.key === "Enter") {
    event.preventDefault();
    sendMessage("person1-message", "Person 1", person1Input.value);
    person1Input.value = "";
  }

});

person2Input.addEventListener("keydown", function (event) {
  if (event.key === "Enter") {
    event.preventDefault();
    sendMessage("person2-message", "Person 2", person2Input.value);
    person2Input.value = "";
  }
});


function sendMessage(messageClass, sender, message) {
    const timestamp = new Date().toLocaleTimeString();
    const formattedMessage = `
      <div class="message-container">
        <div class="message ${messageClass}">${message}</div>
      </div>`;
    chatOutput.innerHTML = formattedMessage + chatOutput.innerHTML; // Aggiungi il nuovo messaggio all'inizio
    
 
  }
