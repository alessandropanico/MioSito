let displayValue = "";

    // Funzione per aggiungere un carattere al display
    function addToDisplay(carattere) {
        displayValue += carattere;
        document.calcolatrice.schermo.value = displayValue;
    }

    // Funzione per cancellare l'ultimo carattere dal display
    function backspace() {
        displayValue = displayValue.slice(0, -1);
        document.calcolatrice.schermo.value = displayValue;
    }

    // Funzione per cancellare tutto il contenuto del display
    function clearDisplay() {
        displayValue = "";
        document.calcolatrice.schermo.value = displayValue;
    }

    // Funzione per aggiungere l'operatore al display
    function addOperator(operator) {
        displayValue += operator;
        document.calcolatrice.schermo.value = displayValue;
    }

    // Funzione per ottenere il risultato dell'espressione nel display
    function calculateResult() {
        try {
            const risultato = eval(displayValue);
            document.calcolatrice.schermo.value = risultato;
            displayValue = risultato.toString();
        } catch (error) {
            document.calcolatrice.schermo.value = "Errore";
            displayValue = "";
        }
    }