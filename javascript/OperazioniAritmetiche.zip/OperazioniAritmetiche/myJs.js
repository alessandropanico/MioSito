// Variabile globale per memorizzare l'operazione scelta
let operazioneSelezionata = null;

// Funzione per pulire il risultato
function annulla() {
    document.getElementById("risultato").innerText = "";
    document.getElementById("numero1").value="";
    document.getElementById("numero2").value="";
}

// Funzioni per gestire la selezione dell'operazione
function selezionaAddizione() {
    operazioneSelezionata = "+";
}

function selezionaSottrazione() {
    operazioneSelezionata = "-";
}

function selezionaMoltiplicazione() {
    operazioneSelezionata = "*";
}

function selezionaDivisione() {
    operazioneSelezionata = "/";
}


// Funzioni di calcolo
function calcola() {
    if (!operazioneSelezionata) {
        document.getElementById("risultato").innerText = "Seleziona un'operazione!";
        return;
    }

    const numero1 = parseFloat(document.getElementById("numero1").value);
    const numero2 = parseFloat(document.getElementById("numero2").value);

    switch (operazioneSelezionata) {
        case "+":
            const risultatoAddizione = numero1 + numero2;
            document.getElementById("risultato").innerText = "Risultato: " + risultatoAddizione;
            break;
        case "-":
            const risultatoSottrazione = numero1 - numero2;
            document.getElementById("risultato").innerText = "Risultato: " + risultatoSottrazione;
            break;
        case "*":
            const risultatoMoltiplicazione = numero1 * numero2;
            document.getElementById("risultato").innerText = "Risultato: " + risultatoMoltiplicazione;
            break;
        case "/":
            if (numero2 !== 0) {
                const risultatoDivisione = numero1 / numero2;
                document.getElementById("risultato").innerText = "Risultato: " + risultatoDivisione;
            } else {
                document.getElementById("risultato").innerText = "Impossibile dividere per zero!";
            }
            break;
    }
}
