//CHIAMATA XML

function chiamataXML(page) {
    document.getElementById("contenuto").style.display = "block";
    var xhttp = new XMLHttpRequest();

    xhttp.open("GET", page, true);
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("contenuto").innerHTML = this.responseText;
        }
    }

    xhttp.send();
}


