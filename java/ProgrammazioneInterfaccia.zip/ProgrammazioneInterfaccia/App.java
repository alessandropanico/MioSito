
public class App {

	public static void main(String[] args) {
		Estrattore E;
		
		System.out.println("IL LANCIO DEL DADO E':");
		E= new Dado();
		System.out.println(E.estrai());
		
		System.out.println("----");
		
		System.out.println("IL LANCIO DELLA MONETA E':");
		E=new Moneta();
		System.out.println(E.estrai());
		
							System.out.println("-----------------------------");
							System.out.println("-----------------------------");
							
		
		Moneta moneta= new Moneta();
		
		System.out.println("Il lancio della moneta e': ");
		System.out.println(moneta.estrai());
		
		Dado dado= new Dado();
		
		System.out.println("Il lancio del dado e': ");
		System.out.println(dado.estrai());
		
		
	}

}
