import java.util.Random;
public class Moneta implements Estrattore{

	@Override
	public String estrai() {
		Random random = new Random();
			int testa = 1;
	        int croce = 2;
	        //int num = random.nextInt(croce + 1 - testa) + testa;
	        int num=random.nextInt(1,3);
	        if (num == 1)
	            return "TESTA";
	        else
	            return "CROCE";

	    }
	}


