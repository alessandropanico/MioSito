
public interface Estrattore 
{
	public String estrai();
}
