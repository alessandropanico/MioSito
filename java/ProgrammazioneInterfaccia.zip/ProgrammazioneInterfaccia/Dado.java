import java.util.Random;

public class Dado implements Estrattore{
	
	public String estrai() {
		Random random= new Random();
		int min=1;
		int max=6;
		//int num= random.nextInt(max + 1 - min) + min;
		int num=random.nextInt(1,7);
		return String.valueOf(num);
		
		
		
	}
		

}
