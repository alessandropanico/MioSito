import java.util.Scanner;

public class NumeroMassimoEMinimo {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int n = 0;
        int numero[];
        int max = Integer.MIN_VALUE; // Inizializziamo max al valore minimo consentito per un intero
        int min = Integer.MAX_VALUE; // Inizializziamo min al valore massimo consentito per un intero
        int indexMax = 0;
        int indexMin = 0;

        System.out.println("Quanti numeri vuoi inserire?");
        n = scanner.nextInt();
        scanner.nextLine();

        numero = new int[n];

        for (int i = 0; i < n; i++) {
            System.out.println("Inserisci il " + (i + 1) + "-mo elemento");
            numero[i] = scanner.nextInt();
            scanner.nextLine();

            // Troviamo il massimo
            if (numero[i] > max) {
                max = numero[i];
                indexMax = i;
            }

            // Troviamo il minimo
            if (numero[i] < min) {
                min = numero[i];
                indexMin = i;
            }
        }

        System.out.println("Il numero piu' grande e' " + max + " e si trova nella posizione " + indexMax);
        System.out.println("Il numero piu' piccolo e' " + min + " e si trova nella posizione " + indexMin);
    }
}
