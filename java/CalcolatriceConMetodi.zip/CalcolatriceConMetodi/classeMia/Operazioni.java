package classeMia;
import java.util.*;

public class Operazioni {

	static Scanner scanner = new Scanner(System.in);

	public static void somma()
	{
		double a=0;
		double b=0;
		double risultato=0;

		System.out.println("ADDIZIONE:");

		System.out.println("Inserisci il primo numero");
		a=scanner.nextDouble();
		scanner.nextLine();
		
		System.out.println("Inserisci il secondo numero");
		b=scanner.nextDouble();
		scanner.nextLine();

		risultato=a+b;

		System.out.println("Il risultato e': "+ risultato);
	}

	public static void sottrazione()
	{
		double a=0;
		double b=0;
		double risultato=0;

		System.out.println("SOTTRAZIONE:");

		System.out.println("Inserisci il primo numero");
		a=scanner.nextDouble();
		scanner.nextLine();
		
		System.out.println("Inserisci il secondo numero");
		b=scanner.nextDouble();
		scanner.nextLine();
		
		risultato=a-b;

		System.out.println("Il risultato e':"+ risultato);

	}

	public static void moltiplicazione()
	{
		double a=0;
		double b=0;
		double risultato=0;

		System.out.println("MOLTIPLICAZIONE:");

		System.out.println("Inserisci il primo numero");
		a=scanner.nextDouble();
		scanner.nextLine();

		System.out.println("Inserisci il secondo numero");
		b=scanner.nextDouble();
		scanner.nextLine();

		risultato=a*b;

		System.out.println("Il risultato e': "+risultato);


	}


	public static void divisione()
	{
		double a=0;
		double b=0;
		double risultato=0;

		System.out.println("DIVISIONE:");

		System.out.println("Inserisci il primo numero");
		a=scanner.nextDouble();
		scanner.nextLine();

		do
		{
			System.out.println("Inserisci il secondo numero e che sia diverso da 0!");
			b=scanner.nextDouble();
			scanner.nextLine();
			if(b!=0)
			{
				System.out.println("Non è possibile dividere un numero per 0! Re-inserisci");
			}
		}while(b==0);

		risultato=a/b;
		
		System.out.println("Il risultato e': "+risultato);
	}
}
