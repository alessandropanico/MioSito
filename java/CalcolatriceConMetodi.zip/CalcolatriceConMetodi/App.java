import java.util.Scanner;
import classeMia.Operazioni;

public class App {

	public static void main(String[] args) {

		Operazioni operazioni = new Operazioni();
		Scanner scanner = new Scanner(System.in);
		int scelta = 0;

		do {
			System.out.println("Quale operazione vuoi effettuare?");
			System.out.println("1 - ADDIZIONE");
			System.out.println("2 - SOTTRAZIONE");
			System.out.println("3 - MOLTIPLICAZIONE");
			System.out.println("4 - DIVISIONE");
			System.out.println("5 - ESCI");
			scelta = scanner.nextInt();
			scanner.nextLine(); // Consuma il newline




			switch (scelta) {
			case 1:
				operazioni.somma();
				System.out.println();
				break;

			case 2:
				operazioni.sottrazione();
				System.out.println();
				break;

			case 3:
				operazioni.moltiplicazione();
				System.out.println();
				break;

			case 4:
				operazioni.divisione();
				System.out.println();
				break;

			case 5:
				System.out.println("Programma terminato.");
				break;

			default:
				System.out.println("Scelta non valida.");
				System.out.println();
			}

		} while (scelta != 5);

		scanner.close();
	}
}
