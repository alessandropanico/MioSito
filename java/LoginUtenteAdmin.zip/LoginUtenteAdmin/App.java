import java.util.ArrayList;
import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        // Crea l'istanza di UserManager
        UserManager userManager = new UserManager();

        Scanner scanner = new Scanner(System.in);
        Utente utenteDefault = new Utente ("Alessandro", "Panico", "alessandro.panico@gmail.com", 27, false);
        Admin adminDefault = new Admin ("Nakama", "Kazama", "nakama.kazama@gmail.com", 27, true);
        
        userManager.aggiungiUtente(utenteDefault);
        userManager.aggiungiAdmin(adminDefault);
        
        int scelta;
        do {
            System.out.println("Cosa vuoi fare?");
            System.out.println("1 - Elenco utenti");
            System.out.println("2 - Elenco admin");
            System.out.println("3 - Aggiungi utente");
            System.out.println("4 - Aggiungi admin");
            System.out.println("5 - Elimina utente");
            System.out.println("6 - Elimina admin");
            System.out.println("7 - ESCI");

            scelta = scanner.nextInt();
            scanner.nextLine();

            switch (scelta) {
                case 1:
                    System.out.println("ELENCO UTENTI");
                    ArrayList<Utente> utentiRegistrati = userManager.getListaUtenti();
                    for (Utente u : utentiRegistrati) {
                        System.out.println(u.getNome() + " " + u.getCognome() + " - " + u.getEmail() + " - " +
                                u.getEta() + " - " + (u.isAdmin() ? "Admin" : "Utente"));
                    }
                    break;
                case 2:
                    System.out.println("ELENCO ADMIN");
                    ArrayList<Admin> adminRegistrati = userManager.getAdminRegistrati();
                    for (Admin a : adminRegistrati) {
                        System.out.println(a.getNome() + " " + a.getCognome() +" "+a.getEmail()+" - "+a.getEta()+ " - Admin");
                    }
                    break;
                case 3:
                    System.out.println("Inserisci nome");
                    String nomeUtente = scanner.nextLine();

                    System.out.println("Inserisci cognome");
                    String cognomeUtente = scanner.nextLine();

                    System.out.println("Inserisci l'email");
                    String emailUtente = scanner.nextLine();

                    System.out.println("Inserisci l'età");
                    int etaUtente = scanner.nextInt();
                    scanner.nextLine();

                    Utente utenteNuovo = new Utente(nomeUtente, cognomeUtente, emailUtente, etaUtente, false);
                    userManager.aggiungiUtente(utenteNuovo);
                    System.out.println("Nuovo utente aggiunto con successo!");
                    break;
                case 4:
                    System.out.println("Inserisci nome");
                    String nomeAdmin = scanner.nextLine();

                    System.out.println("Inserisci cognome");
                    String cognomeAdmin = scanner.nextLine();

                    System.out.println("Inserisci l'email");
                    String emailAdmin = scanner.nextLine();

                    System.out.println("Inserisci l'età");
                    int etaAdmin = scanner.nextInt();
                    scanner.nextLine();

                    Admin adminNuovo = new Admin(nomeAdmin, cognomeAdmin, emailAdmin, etaAdmin, true);
                    userManager.aggiungiAdmin(adminNuovo);
                    System.out.println("Nuovo admin aggiunto con successo!");
                    break;
                case 5:
                    System.out.println("Inserisci email dell'utente da eliminare:");
                    String emailUtenteDaEliminare = scanner.nextLine();
                    Utente utenteDaEliminare = userManager.getUtenteByEmail(emailUtenteDaEliminare);
                    if (utenteDaEliminare != null) {
                        userManager.rimuoviUtente(utenteDaEliminare);
                        System.out.println("Utente eliminato con successo.");
                    } else {
                        System.out.println("Utente non trovato.");
                    }
                    break;
                case 6:
                    System.out.println("Inserisci email dell'admin da eliminare:");
                    String emailAdminDaEliminare = scanner.nextLine();
                    Admin adminDaEliminare = userManager.getAdminByEmail(emailAdminDaEliminare);
                    if (adminDaEliminare != null) {
                        userManager.rimuoviAdmin(adminDaEliminare);
                        System.out.println("Admin eliminato con successo.");
                    } else {
                        System.out.println("Admin non trovato.");
                    }
                    break;
                case 7:
                    System.out.println("Programma terminato.");
                    break;
                default:
                    System.out.println("Scelta non valida.");
                    break;
            }
        } while (scelta != 7);

        scanner.close();
    }
}
