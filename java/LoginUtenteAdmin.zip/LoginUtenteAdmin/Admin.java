class Admin extends Utente {
	
    public Admin(String nome, String cognome, String email, int eta, boolean admin) {
        super(nome, cognome, email, eta, admin);
    }
}
