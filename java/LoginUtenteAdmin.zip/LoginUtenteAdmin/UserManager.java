import java.util.ArrayList;

public class UserManager {

    private ArrayList<Utente> utentiRegistrati = new ArrayList<>();
    private ArrayList<Admin> adminRegistrati = new ArrayList<>();

    public void aggiungiUtente(Utente utente) {
        utentiRegistrati.add(utente);
    }

    public void rimuoviUtente(Utente utente) {
        utentiRegistrati.remove(utente);
    }

    public void aggiungiAdmin(Admin admin) {
        adminRegistrati.add(admin);
    }

    public void rimuoviAdmin(Admin admin) {
        adminRegistrati.remove(admin);
    }

    public ArrayList<Utente> getListaUtenti() {
        return utentiRegistrati;
    }

    public ArrayList<Admin> getAdminRegistrati() {
        return adminRegistrati;
    }

    public Utente getUtenteByEmail(String email) {
        for (Utente u : utentiRegistrati) {
            if (u.getEmail().equals(email)) {
                return u;
            }
        }
        return null; // Utente non trovato
    }

    public Admin getAdminByEmail(String email) {
        for (Admin a : adminRegistrati) {
            if (a.getEmail().equals(email)) {
                return a;
            }
        }
        return null; // Admin non trovato
    }
}
