import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class APP
{
	public static void main( String[] args )
	{
		/*
		 * Per connetterci a MSYQL ci serve la stringa di connessione
		 */
		String strconn = "jdbc:mysql://localhost:3306/gestionale1";
		String username = "root";
		String password = "";
		System.out.println("TENTATIVO DI CONNESSIONE");
		try
		{
			Scanner s = new Scanner(System.in);
			System.out.println("Inserisci il nome prodotto");
			String nome = s.nextLine();
			System.out.println("Inserisci la descrizione");
			String descrizione = s.nextLine();
			System.out.println("Inserisci il prezzo");
			double prezzo = Float.parseFloat(s.nextLine());


			Connection conn = DriverManager.getConnection(strconn, username, password);
			System.out.println("TENTATIVO DI CONNESSIONE ANDATO IN PORTO!");
			System.out.println("INSERIMENTO IN CORSO!");
			String query = "insert into prodotti (nome, descrizione, prezzo) VALUES (?, ?, ?);";

			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setString(1, nome);
			stmt.setString(2, descrizione);
			stmt.setDouble(3, prezzo);
			stmt.executeUpdate();
			System.out.println("FATTO!");
		}
		catch (SQLException e)
		{
			System.out.println("ERORRE MYSL");
		}
	}
}