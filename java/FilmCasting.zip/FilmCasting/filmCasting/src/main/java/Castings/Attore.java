package Castings;

public class Attore {

	private String nome;
	private String cognome;
	private String email;
	private int id;
	
	 public Attore(String nome, String cognome, String email, int id) {
	        this.nome = nome;
	        this.cognome=cognome;
	        this.email=email;
	        this.id = id;
	    }

	    public String getNome() {
	        return nome;
	    }
	    
	    public String getCognome() {
	    	return cognome;
	    }

	   
	    public String getDescrizione() {
	        return email;
	    }

	    public int getId() {
	        return id;
	    }
	    
	    public String getEmail()
	    {
	    	return email;
	    }
}
