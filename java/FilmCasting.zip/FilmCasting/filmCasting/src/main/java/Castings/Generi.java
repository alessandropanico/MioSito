package Castings;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import DB.MySQL.MySQL;
import settings.Conf;

public class Generi {

    public ArrayList<Genere> List() throws SQLException {
        ArrayList<Genere> res = new ArrayList<Genere>();
        MySQL mysql = new MySQL(Conf.dbhost, Conf.dbusername, Conf.dbpassword, Conf.dbport);
        mysql.useDB(Conf.dbname);
        mysql.executeSELQuery("SELECT * FROM `generi`");

        do
        {
            int id = mysql.resultData().getInt("id");
            String nome = mysql.resultData().getString("nome");
            Genere g = new Genere(id, nome);
            res.add(g);
        }   while (mysql.next());


        return res;
    }
    
    
    public void elencoGeneri() {
    	Generi generi = new Generi();
        try {
            ArrayList<Genere> listaGeneri = generi.List();
            for (Genere g : listaGeneri) {
                System.out.println("ID: " + g.getId());
                System.out.println("Nome: " + g.getNome());
                System.out.println("------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void aggiungiGenere() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Inserisci il nome del genere:");
        String nome = scanner.nextLine();
   
        boolean successo = aggiungiGenere(nome);

        if (successo) {
            System.out.println("Nuovo genere aggiunto con successo.");
        } else {
            System.out.println("Si è verificato un errore durante l'aggiunta del produttore.");
        }

        
    }
    
    public boolean aggiungiGenere(String nome)
    {
    	
    	 try {
             MySQL mysql = new MySQL(Conf.dbhost, Conf.dbusername, Conf.dbpassword, Conf.dbport);
             mysql.useDB(Conf.dbname);

             String query = "INSERT INTO `generi` (`nome`) VALUES (?)";
             mysql.prepareUPDQuery(query);
             mysql.stmt.setString(1, nome);
             mysql.stmt.executeUpdate();

             return true;
         } catch (SQLException e) {
             e.printStackTrace();
             return false;
         }
    	
    }
    
    public void cercaGenere() throws SQLException {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Inserisci l'ID del genere da cercare:");
        int searchId = scanner.nextInt();
        scanner.nextLine();

        try {
            MySQL mysql = new MySQL(Conf.dbhost, Conf.dbusername, Conf.dbpassword, Conf.dbport);
            mysql.useDB(Conf.dbname);

            String searchQuery = "SELECT * FROM `generi` WHERE `id` = ?";
            if (mysql.prepareUPDQuery(searchQuery)) {
                mysql.stmt.setInt(1, searchId);

                ResultSet resultSet = mysql.stmt.executeQuery();

                if (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    String nome = resultSet.getString("nome");

                    System.out.println("ID: " + id);
                    System.out.println("Nome: " + nome);
                } else {
                    System.out.println("Nessun genere trovato con l'ID specificato.");
                }
            } else {
                System.out.println("C'è stato un errore nella preparazione della query.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }


    }
    
    public void eliminaGenere() throws SQLException {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Inserisci l'ID del genere da eliminare:");
        int genereID = scanner.nextInt();
        scanner.nextLine();

        try {
            MySQL mysql = new MySQL(Conf.dbhost, Conf.dbusername, Conf.dbpassword, Conf.dbport);
            mysql.useDB(Conf.dbname);

            String deleteQuery = "DELETE FROM `generi` WHERE `id` = ?";
            if (mysql.prepareUPDQuery(deleteQuery)) {
                mysql.stmt.setInt(1, genereID);
                int rowsAffected = mysql.stmt.executeUpdate();

                if (rowsAffected > 0) {
                    System.out.println("Genere eliminato con successo.");
                } else {
                    System.out.println("Nessun genere trovato con l'ID specificato.");
                }
            } else {
                System.out.println("C'è stato un errore nella preparazione della query.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
  
    
}
