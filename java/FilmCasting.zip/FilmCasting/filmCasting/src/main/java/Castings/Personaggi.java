package Castings;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import DB.MySQL.MySQL;
import settings.Conf;

public class Personaggi {

	public ArrayList<Personaggio> List() throws SQLException {
		ArrayList<Personaggio> res = new ArrayList<Personaggio>();
		MySQL mysql = new MySQL(Conf.dbhost, Conf.dbusername, Conf.dbpassword, Conf.dbport);
		mysql.useDB(Conf.dbname);
		mysql.executeSELQuery("SELECT * FROM `personaggi`");

		do {
			int id = mysql.resultData().getInt("id");
			int id_film = mysql.resultData().getInt("id_film");
			String nome = mysql.resultData().getString("nome");
			String sesso = mysql.resultData().getString("sesso");
			String descrizione = mysql.resultData().getString("descrizione");
			Personaggio p = new Personaggio(id, id_film, nome, sesso, descrizione);
			res.add(p);
		} while (mysql.next());

		return res;
	}

	public void elencoPersonaggi()
	{
		Personaggi personaggi = new Personaggi();
		try
		{
			ArrayList<Personaggio>listaPersonaggi= personaggi.List();
			for(Personaggio p: listaPersonaggi)
			{
				System.out.println("ID: "+p.getId());
				System.out.println("ID_FILM: "+p.getId_film());
				System.out.println("Nome: "+p.getNome());
				System.out.println("Descrizione: "+p.getDescrizione());
				System.out.println("Sesso: "+p.getSesso());

			}

		}catch(SQLException e)
		{
			e.printStackTrace();

		}

	}

	public void aggiungiPersonaggio()
	{
		Scanner scanner=new Scanner(System.in);

		System.out.println("Inserisci l'ID_FILM del personaggio");
		int id_film=scanner.nextInt();
		scanner.nextLine();

		System.out.println("Inserisci il nome e cognome del personaggio");
		String nome=scanner.nextLine();

		System.out.println("Inserisci la descrizione del personaggio");
		String descrizione=scanner.nextLine();

		System.out.println("Inserisci il sesso del personaggio");
		String sesso=scanner.nextLine();

		boolean successo = aggiungiPersonaggio(id_film, nome, descrizione, sesso);

		if(successo)
		{
			System.out.println("Nuovo produttore aggiunto con successo.");
		} 
		else
		{
			System.out.println("Si è verificato un errore durante l'aggiunta di un personaggio LOL");
		}

	}
	public boolean aggiungiPersonaggio(int id_film, String nome, String descrizione, String sesso)
	{
		MySQL mysql = new MySQL(Conf.dbhost, Conf.dbusername, Conf.dbpassword, Conf.dbport);
		mysql.useDB(Conf.dbname);

		try
		{
			String query = "INSERT INTO `personaggi` (`id_film`, `nome`, `descrizione`, `sesso`) VALUES (?, ?, ?, ?)";
			mysql.prepareUPDQuery(query);
			mysql.stmt.setInt(1, id_film);
			mysql.stmt.setString(2, nome);
			mysql.stmt.setString(3, descrizione);
			mysql.stmt.setString(4, sesso);
			mysql.stmt.executeUpdate();

			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	public void cercaPersonaggio() {
	    Scanner scanner = new Scanner(System.in);
	    System.out.println("Inserisci l'ID del personaggio che vuoi cercare");
	    
	    int searchId = scanner.nextInt();
	    scanner.nextLine();
	    
	    try {
	        MySQL mysql = new MySQL(Conf.dbhost, Conf.dbusername, Conf.dbpassword, Conf.dbport);
	        mysql.useDB(Conf.dbname);
	        
	        String searchQuery = "SELECT * FROM `personaggi` WHERE `id`=?";
	        if (mysql.prepareUPDQuery(searchQuery)) {
	            mysql.stmt.setInt(1, searchId);
	            
	            ResultSet resultSet = mysql.stmt.executeQuery();
	            
	            if (resultSet.next()) {
	                int id = resultSet.getInt("id");
	                int id_film = resultSet.getInt("id_film");
	                String nome = resultSet.getString("nome");
	                String sesso = resultSet.getString("sesso");
	                String descrizione = resultSet.getString("descrizione");
	                
	                System.out.println("ID: " + id);
	                System.out.println("ID_FILM: " + id_film);
	                System.out.println("Nome: " + nome);
	                System.out.println("Sesso: " + sesso);
	                System.out.println("Descrizione: " + descrizione);
	            } else {
	                System.out.println("Nessun personaggio trovato con l'ID specificato.");
	            }
	        } else {
	            System.out.println("C'è stato un errore nella preparazione della query.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
	
	
	 public void eliminaPersonaggio() throws SQLException {
	        Scanner scanner = new Scanner(System.in);

	        System.out.println("Inserisci l'ID del personaggio da eliminare:");
	        int personaggioID = scanner.nextInt();
	        scanner.nextLine();

	        try {
	            MySQL mysql = new MySQL(Conf.dbhost, Conf.dbusername, Conf.dbpassword, Conf.dbport);
	            mysql.useDB(Conf.dbname);

	            String deleteQuery = "DELETE FROM `personaggi` WHERE `id` = ?";
	            if (mysql.prepareUPDQuery(deleteQuery)) {
	                mysql.stmt.setInt(1, personaggioID);
	                int rowsAffected = mysql.stmt.executeUpdate();

	                if (rowsAffected > 0) {
	                    System.out.println("Personaggio eliminato con successo.");
	                } else {
	                    System.out.println("Nessun produttore trovato con l'ID specificato.");
	                }
	            } else {
	                System.out.println("C'è stato un errore nella preparazione della query.");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }

}
}
