package Castings;

public class Personaggio {
	
	private int id;
	private int id_film;
	private String nome;
	private String sesso;
	private String descrizione;
	
	
	

	public Personaggio(int id, int id_film, String nome, String sesso, String descrizione) {
	    this.id=id;
	    this.id_film = id_film;
	    this.nome=nome;
	    this.sesso = sesso;
	    this.descrizione=descrizione;
	}

   

	public int getId_film() {
		return id_film;
	}

	public void setId_film(int id_film) {
		this.id_film = id_film;
	}

	public String getSesso() {
		return sesso;
	}

	public void setSesso(String sesso) {
		this.sesso = sesso;
	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getNome() {
		return nome;
	}



	public void setNome(String nome) {
		this.nome = nome;
	}



	public String getDescrizione() {
		return descrizione;
	}



	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	
	
}
