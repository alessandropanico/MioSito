package Castings;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import DB.MySQL.MySQL;
import settings.Conf;

public class Films {

	public ArrayList<Film> List() throws SQLException {
		ArrayList<Film> res = new ArrayList<Film>();
		MySQL mysql = new MySQL(Conf.dbhost, Conf.dbusername, Conf.dbpassword, Conf.dbport);
		mysql.useDB(Conf.dbname);
		mysql.executeSELQuery("SELECT * FROM `film`");

		do {
			int id = mysql.resultData().getInt("id");
			int genere_id = mysql.resultData().getInt("genere_id");
			int id_produttore = mysql.resultData().getInt("id_produttore");
			String titolo = mysql.resultData().getString("titolo");
			String descrizione = mysql.resultData().getString("descrizione");

			Film f = new Film(id, genere_id, id_produttore, titolo, descrizione, descrizione, descrizione, null);
			res.add(f);
		} while (mysql.next());

		return res;
	}

	public void elencoFilm() {
		Films films = new Films();
		try {
			ArrayList<Film> listaFilm = films.List();
			for (Film f : listaFilm) {
				System.out.println("ID: " + f.getId());
				System.out.println("Genere ID: " + f.getGenere_id()); // Cambia il nome qui
				System.out.println("ID Produttore: " + f.getId_produttore());
				System.out.println("Titolo: " + f.getTitolo());
				System.out.println("Descrizione: " + f.getDescrizione());
				System.out.println("------------------------");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void aggiungiFilm() {
		Scanner scanner = new Scanner(System.in);

		System.out.println("Inserisci l'ID genere:");
		int genere_id=scanner.nextInt();
		scanner.nextLine();

		System.out.println("Inserisci l'ID produttore:");
		int id_produttore=scanner.nextInt();
		scanner.nextLine();

		System.out.println("Inserisci il titolo:");
		String titolo = scanner.nextLine();

		System.out.println("Inserisci la descrizione:");
		String descrizione = scanner.nextLine();


		boolean successo = aggiungiFilm(genere_id, id_produttore, titolo, descrizione);

		if (successo) {
			System.out.println("Nuovo film aggiunto con successo.");
		} else {
			System.out.println("Si è verificato un errore durante l'aggiunta del film.");
		}



	}

	public boolean aggiungiFilm(int genere_id, int id_produttore, String titolo, String descrizione)
	{
		try {
			MySQL mysql = new MySQL(Conf.dbhost, Conf.dbusername, Conf.dbpassword, Conf.dbport);
			mysql.useDB(Conf.dbname);

			String query = "INSERT INTO `film` (`genere_id`, `id_produttore`, `titolo`, `descrizione`) VALUES (?, ?, ?, ?)";
			mysql.prepareUPDQuery(query);
			mysql.stmt.setInt(1, genere_id);
			mysql.stmt.setInt(2, id_produttore);
			mysql.stmt.setString(3, titolo);
			mysql.stmt.setString(4, descrizione);
			mysql.stmt.executeUpdate();

			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	public void cercaFilm() throws SQLException {
		Scanner scanner = new Scanner(System.in);

		System.out.println("Inserisci l'ID del film da cercare:");
		int searchId = scanner.nextInt();
		scanner.nextLine();

		try {
			MySQL mysql = new MySQL(Conf.dbhost, Conf.dbusername, Conf.dbpassword, Conf.dbport);
			mysql.useDB(Conf.dbname);

			String searchQuery = "SELECT * FROM `film` WHERE `id` = ?";
			if (mysql.prepareUPDQuery(searchQuery)) {
				mysql.stmt.setInt(1, searchId);

				ResultSet resultSet = mysql.stmt.executeQuery();

				if (resultSet.next()) {
					int id = resultSet.getInt("id");
					int genere_id = resultSet.getInt("genere_id");
					int id_produttore = resultSet.getInt("id_produttore");
					String titolo = resultSet.getString("titolo");
					String descrizione = resultSet.getString("descrizione");

					System.out.println("ID: " + id);
					System.out.println("GENERE ID: "+genere_id);
					System.out.println("ID PRODUTTORE: "+id_produttore);
					System.out.println("Titolo: " + titolo);
					System.out.println("Descrizione: " + descrizione);
				} else {
					System.out.println("Nessun film trovato con l'ID specificato.");
				}
			} else {
				System.out.println("C'è stato un errore nella preparazione della query.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}


	}


	public void eliminaFilm() throws SQLException {
		Scanner scanner = new Scanner(System.in);

		System.out.println("Inserisci l'ID del film da eliminare:");
		int filmId = scanner.nextInt();
		scanner.nextLine();

		try {
			MySQL mysql = new MySQL(Conf.dbhost, Conf.dbusername, Conf.dbpassword, Conf.dbport);
			mysql.useDB(Conf.dbname);

			String deleteQuery = "DELETE FROM `film` WHERE `id` = ?";
			if (mysql.prepareUPDQuery(deleteQuery)) {
				mysql.stmt.setInt(1, filmId);
				int rowsAffected = mysql.stmt.executeUpdate();

				if (rowsAffected > 0) {
					System.out.println("Film eliminato con successo.");
				} else {
					System.out.println("Nessun film trovato con l'ID specificato.");
				}
			} else {
				System.out.println("C'è stato un errore nella preparazione della query.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public ArrayList<Film> joinFilmAndGeneri() throws SQLException {
		ArrayList<Film> res = new ArrayList<Film>();
		MySQL mysql = new MySQL(Conf.dbhost, Conf.dbusername, Conf.dbpassword, Conf.dbport);
		mysql.useDB(Conf.dbname);

		String query = "SELECT film.*, generi.nome AS genere_nome, produttori.nome AS produttore_nome "
				+ "FROM film "
				+ "LEFT JOIN generi ON film.genere_id = generi.id "
				+ "LEFT JOIN produttori ON film.id_produttore = produttori.id";

		mysql.executeSELQuery(query);

		while (mysql.next()) {
			int id = mysql.resultData().getInt("id");
			int genere_id = mysql.resultData().getInt("genere_id");
			int id_produttore = mysql.resultData().getInt("id_produttore");
			String titolo = mysql.resultData().getString("titolo");
			String descrizione = mysql.resultData().getString("descrizione");
			String genere_nome = mysql.resultData().getString("genere_nome");
			String produttore_nome = mysql.resultData().getString("produttore_nome");

			Film f = new Film(id, genere_id, id_produttore, titolo, descrizione, genere_nome, produttore_nome, null);
			res.add(f);
		}

		return res;
	}

	public void JoinFilmGeneriProduttori()
	{
		Films films = new Films();
		try {
			ArrayList<Film> filmList = films.joinFilmAndGeneri();
			for (Film f : filmList) {
				System.out.println("ID: " + f.getId());
				System.out.println("Genere: " + f.getGenere_nome()); // Cambia il nome del metodo getter
				System.out.println("ID Produttore: " + f.getId_produttore());
				System.out.println("Titolo: " + f.getTitolo());
				System.out.println("Descrizione: " + f.getDescrizione());
				System.out.println("------------------------");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}



	public ArrayList<Film> getFilmWithCharacters() {
		ArrayList<Film> filmList = new ArrayList<Film>();

		try {
			MySQL mysql = new MySQL(Conf.dbhost, Conf.dbusername, Conf.dbpassword, Conf.dbport);
			mysql.useDB(Conf.dbname);

			String query = "SELECT f.id AS film_id, f.genere_id, f.id_produttore, f.titolo, f.descrizione, " +
					"g.nome AS genere_nome, p.id AS personaggio_id, p.nome AS personaggio_nome, p.sesso, p.descrizione AS personaggio_descrizione " +
					"FROM film f " +
					"LEFT JOIN generi g ON f.genere_id = g.id " +
					"LEFT JOIN personaggi p ON f.id = p.id_film";

			mysql.executeSELQuery(query);

			do{
				int filmId = mysql.resultData().getInt("film_id");
				int genere_id = mysql.resultData().getInt("genere_id");
				int id_produttore = mysql.resultData().getInt("id_produttore");
				String titolo = mysql.resultData().getString("titolo");
				String descrizione = mysql.resultData().getString("descrizione");
				String genere_nome = mysql.resultData().getString("genere_nome");
				int personaggio_id = mysql.resultData().getInt("personaggio_id");
				String personaggio_nome = mysql.resultData().getString("personaggio_nome");
				String sesso = mysql.resultData().getString("sesso");
				String personaggio_descrizione = mysql.resultData().getString("personaggio_descrizione");

				// Cerchiamo il film nella lista filmList
				Film currentFilm = null;
				for (Film film : filmList) {
					if (film.getId() == filmId) {
						currentFilm = film;
						break;
					}
				}

				// Se non abbiamo trovato il film nella lista, creiamolo e aggiungiamolo
				if (currentFilm == null) {
					currentFilm = new Film(filmId, genere_id, id_produttore, titolo, descrizione, genere_nome, null, null);
					filmList.add(currentFilm);
				}

				// Creiamo un nuovo oggetto Personaggio associato al film corrente
				Personaggio personaggio = new Personaggio(personaggio_id, filmId, personaggio_nome, sesso, personaggio_descrizione);
				// Aggiungiamo il personaggio alla lista di personaggi del film corrente
				currentFilm.getPersonaggi().add(personaggio);
			}while (mysql.next());

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return filmList;
	}

	// Metodo per visualizzare i film con i relativi personaggi associati
	public void displayFilmWithCharacters() {
		ArrayList<Film> filmList = getFilmWithCharacters();

		for (Film film : filmList) {
			System.out.println("Film ID: " + film.getId());
			System.out.println("Genere: " + film.getGenere_nome());
			System.out.println("Titolo: " + film.getTitolo());
			System.out.println("Descrizione: " + film.getDescrizione());
			System.out.println("Personaggi associati:");

			ArrayList<Personaggio> personaggi = film.getPersonaggi();
			for (Personaggio personaggio : personaggi) {
				System.out.println("  Nome: " + personaggio.getNome());
				System.out.println("  Sesso: " + personaggio.getSesso());
				System.out.println("  Descrizione: " + personaggio.getDescrizione());
				System.out.println("------------------------");
			}
			System.out.println();
		}
	}









}




