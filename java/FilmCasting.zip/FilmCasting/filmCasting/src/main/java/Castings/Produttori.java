package Castings;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import DB.MySQL.MySQL;
import settings.Conf;

public class Produttori {

    public ArrayList<Produttore> List() throws SQLException {
        ArrayList<Produttore> res = new ArrayList<Produttore>();
        MySQL mysql = new MySQL(Conf.dbhost, Conf.dbusername, Conf.dbpassword, Conf.dbport);
        mysql.useDB(Conf.dbname);
        mysql.executeSELQuery("SELECT * FROM `produttori`");

        do {
            int id = mysql.resultData().getInt("id");
            String nome = mysql.resultData().getString("nome");
            String descrizione = mysql.resultData().getString("descrizione");
            Produttore p = new Produttore(nome, descrizione, id);
            res.add(p);
        } while (mysql.next());

        return res;
    }

    public void elencoProduttori() {
        Produttori produttori = new Produttori();
        try {
            ArrayList<Produttore> listaProduttori = produttori.List();
            for (Produttore p : listaProduttori) {
                System.out.println("ID: " + p.getId());
                System.out.println("Nome: " + p.getNome());
                System.out.println("Descrizione: " + p.getDescrizione());
                System.out.println("------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void aggiungiProduttore() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Inserisci il nome del produttore:");
        String nome = scanner.nextLine();

        System.out.println("Inserisci la descrizione del produttore:");
        String descrizione = scanner.nextLine();

        boolean successo = aggiungiProduttore(nome, descrizione);

        if (successo) {
            System.out.println("Nuovo produttore aggiunto con successo.");
        } else {
            System.out.println("Si è verificato un errore durante l'aggiunta del produttore.");
        }

        
    }

    private boolean aggiungiProduttore(String nome, String descrizione) {
        try {
            MySQL mysql = new MySQL(Conf.dbhost, Conf.dbusername, Conf.dbpassword, Conf.dbport);
            mysql.useDB(Conf.dbname);

            String query = "INSERT INTO `produttori` (`nome`, `descrizione`) VALUES (?, ?)";
            mysql.prepareUPDQuery(query);
            mysql.stmt.setString(1, nome);
            mysql.stmt.setString(2, descrizione);
            mysql.stmt.executeUpdate();

            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public void cercaProduttore() throws SQLException {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Inserisci l'ID del produttore da cercare:");
        int searchId = scanner.nextInt();
        scanner.nextLine();

        try {
            MySQL mysql = new MySQL(Conf.dbhost, Conf.dbusername, Conf.dbpassword, Conf.dbport);
            mysql.useDB(Conf.dbname);

            String searchQuery = "SELECT * FROM `produttori` WHERE `id` = ?";
            if (mysql.prepareUPDQuery(searchQuery)) {
                mysql.stmt.setInt(1, searchId);

                ResultSet resultSet = mysql.stmt.executeQuery();

                if (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    String nome = resultSet.getString("nome");
                    String descrizione = resultSet.getString("descrizione");

                    System.out.println("ID: " + id);
                    System.out.println("Nome: " + nome);
                    System.out.println("Descrizione: " + descrizione);
                } else {
                    System.out.println("Nessun produttore trovato con l'ID specificato.");
                }
            } else {
                System.out.println("C'è stato un errore nella preparazione della query.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }


    }
    
    public void eliminaProduttore() throws SQLException {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Inserisci l'ID del produttore da eliminare:");
        int produttoreId = scanner.nextInt();
        scanner.nextLine();

        try {
            MySQL mysql = new MySQL(Conf.dbhost, Conf.dbusername, Conf.dbpassword, Conf.dbport);
            mysql.useDB(Conf.dbname);

            String deleteQuery = "DELETE FROM `produttori` WHERE `id` = ?";
            if (mysql.prepareUPDQuery(deleteQuery)) {
                mysql.stmt.setInt(1, produttoreId);
                int rowsAffected = mysql.stmt.executeUpdate();

                if (rowsAffected > 0) {
                    System.out.println("Produttore eliminato con successo.");
                } else {
                    System.out.println("Nessun produttore trovato con l'ID specificato.");
                }
            } else {
                System.out.println("C'è stato un errore nella preparazione della query.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }


}
