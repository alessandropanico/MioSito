package Castings;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import DB.MySQL.MySQL;
import settings.Conf;

public class Attori {

	public ArrayList<Attore> List() throws SQLException {
		ArrayList<Attore> res = new ArrayList<Attore>();
		MySQL mysql = new MySQL(Conf.dbhost, Conf.dbusername, Conf.dbpassword, Conf.dbport);
		mysql.useDB(Conf.dbname);
		mysql.executeSELQuery("SELECT * FROM `attori`");

		do {
			int id = mysql.resultData().getInt("id");
			String nome = mysql.resultData().getString("nome");
			String cognome = mysql.resultData().getString("cognome");
			String email = mysql.resultData().getString("email");
			Attore a = new Attore(nome, cognome, email, id);
			res.add(a);
		} while (mysql.next());

		return res;
	}

	public void elencoAttori() 
	{
		Attori attori = new Attori();
		try
		{
			ArrayList<Attore>listaAttori = attori.List();
			for(Attore a: listaAttori)
			{
				System.out.println("ID: "+a.getId());
				System.out.println("Nome: "+a.getNome());
				System.out.println("Cognome: "+a.getCognome());
				System.out.println("E-mail: "+a.getEmail());
			}

		}
		catch(SQLException e)
		{
			e.printStackTrace();

		}


	}

	public void aggiungiAttore() 
	{
		Scanner scanner = new Scanner(System.in);

		System.out.println("Inserisci il nome dell' attore:");
		String nome = scanner.nextLine();

		System.out.println("Inserisci il cognome dell'attore");
		String cognome = scanner.nextLine();

		System.out.println("Insersci l'email dell'attore");
		String email = scanner.nextLine();

		boolean successo = aggiungiAttore(nome, cognome, email);

		if (successo) {
			System.out.println("Nuovo attore aggiunto con successo.");
		} else {
			System.out.println("Si è verificato un errore durante l'aggiunta del attore.");
		}


	}
	public boolean aggiungiAttore(String nome, String cognome, String email) 
	{
		MySQL mysql = new MySQL(Conf.dbhost, Conf.dbusername, Conf.dbpassword, Conf.dbport);
		mysql.useDB(Conf.dbname);

		try
		{
			String query = "INSERT INTO `attori` (`nome`, `cognome`, `email`) VALUES (?, ?, ?)";
			mysql.prepareUPDQuery(query);
			mysql.stmt.setString(1, nome);
			mysql.stmt.setString(2, cognome);
			mysql.stmt.setString(3, email);
			mysql.stmt.executeUpdate();

			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	
	
	
	public void cercaAttore()
	{
		Scanner scanner = new Scanner (System.in);
		System.out.println("Inserisci L'ID dell'attore che vuoi cercare");
		int searchId = scanner.nextInt();
		scanner.nextLine();
		
		  try {
	            MySQL mysql = new MySQL(Conf.dbhost, Conf.dbusername, Conf.dbpassword, Conf.dbport);
	            mysql.useDB(Conf.dbname);

	            String searchQuery = "SELECT * FROM `attori` WHERE `id` = ?";
	            if (mysql.prepareUPDQuery(searchQuery)) {
	                mysql.stmt.setInt(1, searchId);

	                ResultSet resultSet = mysql.stmt.executeQuery();

	                if (resultSet.next()) {
	                    int id = resultSet.getInt("id");
	                    String nome = resultSet.getString("nome");
	                    String cognome = resultSet.getString("cognome");
	                    String email = resultSet.getString("email");
	                    

	                    System.out.println("ID: " + id);
	                    System.out.println("Nome: " + nome);
	                    System.out.println("Descrizione: " + cognome);
	                    System.out.println("E-mail: "+ email);
	                } else {
	                    System.out.println("Nessun produttore trovato con l'ID specificato.");
	                }
	            } else {
	                System.out.println("C'è stato un errore nella preparazione della query.");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	}
	
	public void eliminaAttore()
	{
		  Scanner scanner = new Scanner(System.in);

	        System.out.println("Inserisci l'ID del attore da eliminare:");
	        int produttoreId = scanner.nextInt();
	        scanner.nextLine();

	        try {
	            MySQL mysql = new MySQL(Conf.dbhost, Conf.dbusername, Conf.dbpassword, Conf.dbport);
	            mysql.useDB(Conf.dbname);

	            String deleteQuery = "DELETE FROM `attori` WHERE `id` = ?";
	            if (mysql.prepareUPDQuery(deleteQuery)) {
	                mysql.stmt.setInt(1, produttoreId);
	                int rowsAffected = mysql.stmt.executeUpdate();

	                if (rowsAffected > 0) {
	                    System.out.println("Produttore eliminato con successo.");
	                } else {
	                    System.out.println("Nessun produttore trovato con l'ID specificato.");
	                }
	            } else {
	                System.out.println("C'è stato un errore nella preparazione della query.");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }

	    }
	}
	
	

	
	
	
	
	
	
	
	

