package Castings;

public class Produttore {
    private String nome;
    private String descrizione;
    private int id;

    public Produttore(String nome, String descrizione, int id) {
        this.nome = nome;
        this.descrizione = descrizione;
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

   
    public String getDescrizione() {
        return descrizione;
    }

    public int getId() {
        return id;
    }
}
