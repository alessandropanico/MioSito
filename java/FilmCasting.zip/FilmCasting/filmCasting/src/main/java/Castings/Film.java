package Castings;

import java.util.ArrayList;

public class Film {

	private int id;
	private int genere_id;
	private int id_produttore;
	private String titolo;
	private String descrizione;
	private String genere_nome;
	private String produttore_nome;
    private ArrayList<Personaggio> personaggi;

	
    public Film(int id, int genere_id, int id_produttore, String titolo, String descrizione, String genere_nome, String produttore_nome, ArrayList<Personaggio> personaggi) {
        this.id = id;
        this.genere_id = genere_id;
        this.id_produttore = id_produttore;
        this.titolo = titolo;
        this.descrizione = descrizione;
        this.setGenere_nome(genere_nome);
        this.setProduttore_nome(produttore_nome);
        this.personaggi = personaggi;
        
        if (personaggi == null) {
            this.personaggi = new ArrayList<Personaggio>();
        } else {
            this.personaggi = personaggi;
        }
    
    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getGenere_id()
	{
		return genere_id;
	}
	
	public void setGenere_id(int genere_id)
	{
		this.genere_id=id;
	}

	public int getId_produttore() {
		return id_produttore;
	}

	public void setId_produttore(int id_produttore) {
		this.id_produttore = id_produttore;
	}

	public String getTitolo() {
		return titolo;
	}

	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public String getGenere_nome() {
		return genere_nome;
	}

	public void setGenere_nome(String genere_nome) {
		this.genere_nome = genere_nome;
	}

	public String getProduttore_nome() {
		return produttore_nome;
	}

	public void setProduttore_nome(String produttore_nome) {
		this.produttore_nome = produttore_nome;
	}

	public ArrayList<Personaggio> getPersonaggi() {
		return personaggi;
	}

	public void setPersonaggi(ArrayList<Personaggio> personaggi) {
		this.personaggi = personaggi;
	}
	
	
	
}	

