package settings;

public class Conf {
public static String dbhost = "localhost";
public static String dbusername = "root";
public static String dbpassword = "";
public static String dbport = "3306";
public static String dbname = "filmcasting";
}