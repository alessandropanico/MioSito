package DB.MySQL;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class MySQL {
	// Variabili di istanza per le informazioni di connessione e gestione degli errori
	private Connection conn;
	private String host;
	private String username;
	private String password;
	private String database;
	private String port;
	private int errorCode;
	private String errorMess;
	public PreparedStatement stmt;
	private ResultSet result;
	private int realCount;

	// Costruttore predefinito
	public MySQL() {
		// Inizializzazione delle variabili di connessione e reset degli errori
		this.host = "";
		this.username = "";
		this.password = "";
		this.database = "";
		this.port = "";
		this.conn = null;
		this.stmt = null;
		this.resetErrors();
	}

	// Costruttore con parametri per host, username, password e porta
	public MySQL(String host, String username, String password, String port) {
		// Chiamata al costruttore predefinito
		this();
		// Impostazione delle informazioni di connessione
		this.host = host;
		this.username = username;
		this.password = password;
		this.port = port;
		// Connessione al database
		this.connect();
	}

	// Costruttore con parametri per host, username e password (porta predefinita: 3306)
	public MySQL(String host, String username, String password) {
		this(host, username, password, "3306");
	}

	// Metodo per reimpostare gli errori
	private void resetErrors() {
		this.errorCode = 0;
		this.errorMess = "";
	}

	// Metodi per impostare le informazioni di connessione
	public void setHost(String host) {
		this.host = host;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	// Metodo per connettersi al database
	public boolean connect() {
		boolean res = false;
		// Reimpostazione degli errori
		this.resetErrors();
		// Stringa di connessione
		String strconn = "jdbc:mysql://" + this.host + ":" + this.port + "/" + this.database;
		try {
			// Creazione della connessione
			this.conn = DriverManager.getConnection(strconn, this.username, this.password);
			res = true;
		} catch (SQLException e) {
			res = false;
			// Gestione degli errori
			this.errorCode = e.getErrorCode();
			this.errorMess = e.getMessage();
		}
		return res;
	}

	// Metodo per utilizzare un database specifico
	public boolean useDB(String database) {
		this.database = database;
		// Connessione al database specificato
		return this.connect();
	}

	// Metodo per ottenere il riferimento all'oggetto Connection
	public Connection connectionRef() {
		return this.conn;
	}

	// Metodo per verificare se la connessione è attiva
	public boolean isConnected() {
		return (this.connectionRef() != null);
	}

	/*
	 * QUERY DI UPDATE => modificano qualcosa (aggiungono un rec, eliminano un record, modificano un record, ecc)
	 * QUERY DI EXECUTE => sono delle semplici selezioni: cioè ci forniscono liste di record, di colonne, ricerche, ecc
	 */

	// Metodo per preparare una query di aggiornamento
	public boolean prepareUPDQuery(String query) throws SQLException {
		boolean res = false;
		try {
			// Creazione dell'oggetto PreparedStatement per la query precompilata
			this.stmt = this.conn.prepareStatement(query);
			res = true;
		} catch (SQLException e) {
			res = false;
		}
		return res;
	}

	// Metodo per eseguire una query di aggiornamento
	public boolean executeUPDQuery(String query) throws SQLException {
		boolean res = false;
		try {
			// Creazione di un oggetto PreparedStatement e esecuzione della query di aggiornamento
			PreparedStatement stmt = this.conn.prepareStatement(query);
			stmt.executeUpdate();
			res = true;
		} catch (SQLException e) {
			res = false;
			// Gestione degli errori
			this.errorCode = e.getErrorCode();
			this.errorMess = e.getMessage();
		}
		return res;
	}

	// Metodo per eseguire una query di selezione
	public boolean executeSELQuery(String query) throws SQLException {
		boolean res = false;
		this.result = null;
		try {
			// Creazione dell'oggetto PreparedStatement per la query di selezione
			// ResultSet.TYPE_SCROLL_INSENSITIVE e ResultSet.TYPE_FORWARD_ONLY consentono la navigazione nel ResultSet
			this.stmt = this.conn.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.TYPE_FORWARD_ONLY);
			// Esecuzione della query e ottenimento del ResultSet
			this.result = this.stmt.executeQuery();
			if (this.result != null) {
				this.result.first();
				this.myCount();
				res = true;
			}
		} catch (SQLException e) {
			res = false;
			// Gestione degli errori
			this.errorCode = e.getErrorCode();
			this.errorMess = e.getMessage();
		}
		return res;
	}




	// Metodo per eseguire una query di selezione
	public boolean executeSELQuery(String query, boolean noFirst) throws SQLException {
		boolean res = false;
		this.result = null;
		try {
			// Creazione dell'oggetto PreparedStatement per la query di selezione
			// ResultSet.TYPE_SCROLL_INSENSITIVE e ResultSet.TYPE_FORWARD_ONLY consentono la navigazione nel ResultSet
			this.stmt = this.conn.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.TYPE_FORWARD_ONLY);
			// Esecuzione della query e ottenimento del ResultSet
			this.result = this.stmt.executeQuery();
			if (this.result != null) {
				if (!noFirst)
				{
					this.result.first();
				}
				this.myCount();
				this.result.beforeFirst();
				res = true;
			}
		} catch (SQLException e) {
			res = false;
			// Gestione degli errori
			this.errorCode = e.getErrorCode();
			this.errorMess = e.getMessage();
		}
		return res;
	}


	// Metodo per contare il numero di righe nel ResultSet corrente
	public int myCount() {
		int res = -1;
		if (this.result != null) {
			try {
				if (this.result.last()) {
					this.realCount = this.result.getRow();
					this.result.first();
				}
			} catch (SQLException e) {
				res = -1;
				// Gestione degli errori
				this.errorCode = e.getErrorCode();
				this.errorMess = e.getMessage();
			}
		}
		return res;
	}

	public int count()
	{
		return this.realCount;
	}

	// Metodo per spostarsi alla riga successiva nel ResultSet corrente
	public boolean next() {
		boolean res = false;
		if (this.result != null) {
			try {
				res = this.result.next();
			} catch (SQLException e) {
				res = false;
				// Gestione degli errori
				this.errorCode = e.getErrorCode();
				this.errorMess = e.getMessage();
			}
		}
		return res;
	}

	// Metodo per ottenere l'oggetto ResultSet corrente
	public ResultSet resultData() {
		return this.result;
	}
}