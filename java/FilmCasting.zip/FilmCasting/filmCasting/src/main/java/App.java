import DB.MySQL.MySQL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import Castings.Produttore;
import Castings.Produttori;
import Castings.Attori;
import Castings.Films;
import Castings.Generi;
import Castings.Personaggi;

public class App {
	public static void main(String[] args) throws SQLException {

		Scanner scanner = new Scanner (System.in);

		Produttori produttori = new Produttori();
		Attori attori = new Attori();
		Personaggi personaggi = new Personaggi();
		Generi generi = new Generi();
		Films films = new Films();

		int sceltaCasting=0;
		int sceltaProduttori=0;
		int sceltaAttori=0;
		int sceltaPersonaggi=0;
		int sceltaGeneri=0;
		int sceltaFilms=0;

		System.out.println("CHE INFORMAZIONI VUOI VISUALIZZARE/MODIFICARE?");
		System.out.println("1 - PRODUTTORI");
		System.out.println("2 - ATTORI");
		System.out.println("3 - PERSONAGGI");
		System.out.println("4 - GENERI");
		System.out.println("5 - FILM");

		sceltaCasting=scanner.nextInt();
		scanner.nextLine();

		switch(sceltaCasting)
		{

		case 1:
			do
			{
				System.out.println("SCEGLI COSA FARE CON I PRODUTTORI:");
				System.out.println("1 - VISUALIZZA ELENCO PRODUTTORI");
				System.out.println("2 - AGGIUNGI PRODUTTORE");
				System.out.println("3 - CERCA PRODUTTORE");
				System.out.println("4 - ELIMINA PRODUTTORE");
				System.out.println("5 - ESCI");
				sceltaProduttori=scanner.nextInt();
				scanner.nextLine();


				switch(sceltaProduttori)
				{
				case 1:
					//ELENCO PRODUTTORI
					System.out.println("ELENCO PRODUTTORI:");
					produttori.elencoProduttori();
					System.out.println();
					break;

				case 2:
					//AGGIUNGI PRODUTTORI
					produttori.aggiungiProduttore();
					System.out.println();
					break;

				case 3:
					//RICERCA PRODUTTORI
					produttori.cercaProduttore();
					System.out.println();
					break;

				case 4:
					//ELIMINA PRODUTTORE
					produttori.eliminaProduttore();
					System.out.println();
					break;

				default:
					System.out.println("Fine con i prodottori");
				}
			}while(sceltaProduttori!=5);

			System.out.println();

		case 2:
			do
			{
				System.out.println("SCEGLI COSA FARE CON GLI ATTORI:");
				System.out.println("1 - VISUALIZZA ELENCO ATTORI");
				System.out.println("2 - AGGIUNGI ATTORE");
				System.out.println("3 - CERCA ATTORE");
				System.out.println("4 - ELIMINA ATTORE");
				System.out.println("5 - ESCI");
				sceltaAttori=scanner.nextInt();
				scanner.nextLine();

				switch (sceltaAttori)
				{

				case 1:
					System.out.println("ELENCO ATTORI:");
					attori.elencoAttori();
					System.out.println();
					break;

				case 2:
					attori.aggiungiAttore();
					System.out.println();
					break;

				case 3:
					attori.cercaAttore();
					System.out.println();
					break;

				case 4:
					attori.eliminaAttore();	
					System.out.println();

				default:
					System.out.println("Ciao");

				}
			}while(sceltaAttori!=5);


			System.out.println();

		case 3:

			do
			{
				System.out.println("SCEGLI COSA FARE CON I PERSONAGGI:");
				System.out.println("1 - VISUALIZZA ELENCO PERSONAGGI");
				System.out.println("2 - AGGIUNGI PERSONAGGIO");
				System.out.println("3 - CERCA PERSONAGGIO");
				System.out.println("4 - ELIMINA PERSONAGGIO");
				System.out.println("5 - ESCI");
				sceltaPersonaggi=scanner.nextInt();
				scanner.nextLine();

				switch (sceltaPersonaggi)

				{

				case 1:
					System.out.println("ELENCO PERSONAGGI");
					personaggi.elencoPersonaggi();
					System.out.println();
					break;

				case 2:
					personaggi.aggiungiPersonaggio();
					System.out.println();
					break;

				case 3:
					personaggi.cercaPersonaggio();
					System.out.println();
					break;

				case 4:
					personaggi.eliminaPersonaggio();
					System.out.println();
					break;

				default:
					System.out.println("Ciao");
				}

			}while(sceltaPersonaggi!=5);

		case 4:

			do
			{
				System.out.println("SCEGLI COSA FARE CON I GENERI:");
				System.out.println("1 - VISUALIZZA ELENCO GENERI");
				System.out.println("2 - AGGIUNGI GENERE");
				System.out.println("3 - CERCA GENERE");
				System.out.println("4 - ELIMINA GENERE");
				System.out.println("5 - ESCI");
				sceltaGeneri=scanner.nextInt();
				scanner.nextLine();

				switch(sceltaGeneri)
				{

				case 1:
					System.out.println("ELENCO GENERI");
					generi.elencoGeneri();
					System.out.println();
					break;

				case 2:
					generi.aggiungiGenere();
					System.out.println();
					break;

				case 3:
					generi.cercaGenere();
					System.out.println();
					break;

				case 4:
					generi.eliminaGenere();
					System.out.println();
					break;

				default:
					System.out.println("Ciao Snake!");
				}
			}while(sceltaGeneri!=5);


		case 5:

			do
			{
				System.out.println("SCEGLI COSA FARE CON I FILM:");
				System.out.println("1 - VISUALIZZA ELENCO FILM");
				System.out.println("2 - AGGIUNGI FILM");
				System.out.println("3 - CERCA FILM");
				System.out.println("4 - ELIMINA FILM");
				System.out.println("5 - ESCI");
				sceltaFilms=scanner.nextInt();
				scanner.nextLine();

				switch(sceltaFilms)
				{

				case 1:
					System.out.println("ELENCO FILM");
					films.elencoFilm();
					System.out.println();
					break;

				case 2:
					films.aggiungiFilm();
					System.out.println();
					break;

				case 3:
					films.cercaFilm();
					System.out.println();
					break;

				case 4:
					films.eliminaFilm();
					System.out.println();
					break;

				default:
					System.out.println("Ciao belloooo!");

				}

			}while(sceltaFilms!=5);

		}

		//JOIN

		int sceltaJoin=0;

		System.out.println("Scegli quale join effettuare:");
		System.out.println("1 - FILM-GENERE-PRODUTTORI");
		System.out.println("2 - FILM-PERSONAGGI");
		sceltaJoin=scanner.nextInt();
		scanner.nextLine();
		
		switch(sceltaJoin)
		{
		case 1:
			System.out.println("JOIN TRA FILM, GENERE, PRODUTTORE:");
			films.JoinFilmGeneriProduttori();
			break;

		case 2:
			System.out.println("JOIN TRA FILM E PERSONAGGIO");
			films.displayFilmWithCharacters();
			break;
			
		default:
			System.out.println("CIAO!");
		}
		
	}
}
