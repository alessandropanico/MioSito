
public class App {

	public static void main(String[] args) {

		Quadrato q= new Quadrato();
		q.stampaNome();
		System.out.println("L'area del quadrato e' "+q.getArea());
		
		System.out.println();
		
		Rettangolo r= new Rettangolo();
		r.stampaNome();
		System.out.println("L'area del rettangolo e' "+r.getArea());

	}

}
