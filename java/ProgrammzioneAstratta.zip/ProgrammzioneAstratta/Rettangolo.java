
public class Rettangolo extends Figura{
	
	public double base,altezza;

	public Rettangolo() {
		super("Rettangolo");
		this.base=5;
		this.altezza=10;
	}
	
	public Rettangolo(double base, double altezza)
	{
		super("Rettangolo");
		this.base=base;
		this.altezza=altezza;
	}

	@Override
	public double getArea() {
		// TODO Auto-generated method stub
		return this.base+this.altezza;
	}

}
