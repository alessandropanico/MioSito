
public  abstract class Figura {
	
	public String nome;
	
	public Figura(String nome)
	{
		this.nome=nome;
	}
	
	public abstract double getArea();
	
	
	public void stampaNome()
	{
		System.out.println("Il nome della forma geometrica e' "+this.nome);
	}
	
	

}
