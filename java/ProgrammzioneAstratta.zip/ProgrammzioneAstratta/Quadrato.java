
public class Quadrato extends Figura {
	
	public double lato;

	public Quadrato() {
		super("Quadrato");
		this.lato=10;
	}
	
	public Quadrato(double lato)
	{
		super("Quadrato");
		this.lato=lato;
	}

	@Override
	public double getArea() {
		
		return this.lato*this.lato;
	}

}
