package com.alessandro.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.alessandro.demo.entities.categorieEntity;
import com.alessandro.demo.repositories.categorieRepository;

import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;

@Service
public class categorieService {

	private final categorieRepository IDC;


	public categorieService(categorieRepository IDC)
	{
		this.IDC=IDC;
	}


	public List<categorieEntity> getCategorie() {

		return IDC.findAll();
	}


	public categorieEntity createCategorie(categorieEntity categorie) {

		return this.IDC.save(categorie);
	}


	public Optional<categorieEntity> ricercaPerID(Long id) {
		return this.IDC.findById(id);
	}


	public List<categorieEntity> ricercaPerNome(String nome) {
		return this.IDC.findByNome(nome);
	}

	public List<categorieEntity> ricercaPerDescrizione(String descrizione) {
		return this.IDC.findByDescrizioneContainingIgnoreCase(descrizione);

	}

	//MODIFICA
	public categorieEntity updateCategoria(Long id, categorieEntity categoria) {
		// Controlla se il dipendente con l'id specificato esiste nel database
		categorieEntity existingCategoria = this.IDC.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("Categoria non trovata"));

		// Effettua le modifiche al dipendente esistente con i dati forniti
		existingCategoria.setNome(categoria.getNome());
		existingCategoria.setDescrizione(categoria.getDescrizione());


		// Salva le modifiche nel database
		return this.IDC.save(existingCategoria);
	}


	//ELIMINAZIONE
	public void deleteCategoriaById(Long id) {
		this.IDC.deleteById(id);
	}


	// ELIMINAZIONE CATEGORIA E PRODOTTI
	@Transactional
	public void deleteCategoriaAndProdottiByCategoryId(Long categoryId) {
		this.IDC.deleteProdottiByCategoryId(categoryId);
		this.IDC.deleteById(categoryId);
	}

}










