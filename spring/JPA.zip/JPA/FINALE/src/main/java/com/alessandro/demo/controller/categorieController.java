package com.alessandro.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alessandro.demo.entities.categorieEntity;
import com.alessandro.demo.repositories.categorieRepository;
import com.alessandro.demo.service.categorieService;

import jakarta.transaction.Transactional;


@RestController
@RequestMapping("/api/categorie")
public class categorieController {
	
	private final categorieService categorieService;
    
    public categorieController(categorieService categorieService)
    {
        this.categorieService = categorieService;
    }
    
    //Lista DIPENDNETI
    @GetMapping("/listacategorie")
    public List<categorieEntity> getCategorie() {
        return this.categorieService.getCategorie();
    }
    
    @PostMapping("/aggiungicategoria")
    public ResponseEntity<String> createCategorie(@RequestBody categorieEntity categorie) {
        try {
            categorieEntity newCategoria = categorieService.createCategorie(categorie);
            return ResponseEntity.ok("Categoria creato con successo con ID: " + newCategoria.getId());
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Errore durante la creazione della categoria: " + e.getMessage());
        }
    }
    
    
    //RICERCA PER ID
    @GetMapping("/byid/{id}")
    public Optional<categorieEntity> ricercaCategoriaPerID(@PathVariable Long id) {
        return categorieService.ricercaPerID(id);
    }

    //RICERCA PER NOME
    @GetMapping("/bynome/{nome}")
    public List<categorieEntity> ricercaCategoriaPerNome(@PathVariable String nome) {
        return categorieService.ricercaPerNome(nome);
    }
    
    //RICERCA PER DESCRIZIONE
    @GetMapping("/bydescrizione/{descrizione}")
    public List<categorieEntity> ricercaCategoriaPerDescrizione(@PathVariable String descrizione) {
        return categorieService.ricercaPerDescrizione(descrizione);
    }
    
    //MODIFICA
    @PutMapping("/modifica/{id}")
    public categorieEntity updateCategoria(@PathVariable Long id, @RequestBody categorieEntity categorie) {
        return categorieService.updateCategoria(id, categorie);
    }
    
    
    //ELIMINAZIONE
    @DeleteMapping("/eliminacategoria/{id}")
    public ResponseEntity<String> deleteCategoriaById(@PathVariable Long id) {
    	categorieService.deleteCategoriaById(id);
    	return ResponseEntity.ok("Eliminazione riuscita");
    }
    
    
    //ELIMINA CON PRODOTTO
    @DeleteMapping("/eliminaconprodotto/{id}")
    public void deleteCategoria(@PathVariable Long id) {
        categorieService.deleteCategoriaAndProdottiByCategoryId(id);
    }
}
    
    
    
    




