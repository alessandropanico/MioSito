package com.alessandro.demo.tables;

public class prodottiTAB {
	
	private Long id;
	private String nome;
	private Long categoria;
	private String descrizione;
	private int costo;
	private String codiceprodotto;
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Long getId_categoria() {
		return categoria;
	}
	public void setIdCategoria(Long categoria) {
		this.categoria = categoria;
	}
	public String getDescrizione() {
		return descrizione;
	}
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	public int getCosto() {
		return costo;
	}
	public void setCosto(int costo) {
		this.costo = costo;
	}
	public String getCodiceprodotto() {
		return codiceprodotto;
	}
	public void setCodiceprodotto(String codiceprodotto) {
		this.codiceprodotto = codiceprodotto;
	}
	
	

}
