package com.alessandro.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alessandro.demo.entities.categorieEntity;
import com.alessandro.demo.entities.dipendentiEntity;
import com.alessandro.demo.entities.prodottiEntity;
import com.alessandro.demo.service.prodottiService;

@RestController
@RequestMapping("/api/prodotti")
public class prodottiController {
	
	private final prodottiService prodottiService;
	
	public prodottiController(prodottiService prodottiService)
	{
		this.prodottiService=prodottiService;
	}

	
	 //Lista DIPENDNETI
    @GetMapping("/listaprodotti")
    public List<prodottiEntity> getProdotti() {
        return this.prodottiService.getProdotti();
    }
    
    
    @PostMapping("/aggiungiprodotto")
    public ResponseEntity<String> createProdotto(@RequestBody prodottiEntity prodotto) {
        try {
        	prodottiEntity newProdotto = prodottiService.createProdotto(prodotto);
            return ResponseEntity.ok("Prodotto creato con successo con ID: " + newProdotto.getId());
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Errore durante la creazione del prodotto: " + e.getMessage());
        }
    }
    
    
    //RICERCA PER ID
    @GetMapping("/byid/{id}")
    public Optional<prodottiEntity> ricercaProdottiPerID(@PathVariable Long id) {
        return prodottiService.ricercaPerID(id);
    }
    
    
   //RICERCA PER NOME
   @GetMapping("/bynome/{nome}")
   public List<prodottiEntity> ricercaProdottoPerNome(@PathVariable String nome) {
       return prodottiService.ricercaPerNomeProdotto(nome);
   }

    
   //RICERCA PER CATEGORIA
   @GetMapping("/bycategoria/{categoria}")
   public List<prodottiEntity> ricercaProdottoPerCategoria(@PathVariable Long categoria) {
	   return prodottiService.ricercaProdottoPerCategoria(categoria);
   }
   
   
   
   //RICERCA PER DESCRIZIONE
   @GetMapping("/bydescrizione/{descrizione}")
   public List<prodottiEntity> ricercaProdottoPerDescrizione(@PathVariable String descrizione) {
       return prodottiService.ricercaProdottoPerDescrizione(descrizione);
   }
   
   
   //RICERCA PER COSTO
   @GetMapping("/bycosto/{costo}")
   public List<prodottiEntity> ricercaProdottoPerCosto(@PathVariable int costo) {
	   return prodottiService.ricercaProdottoPerCosto(costo);
   }
   
   
   //MODIFICA
   @PutMapping("/modifica/{id}")
   public prodottiEntity updateProdotto(@PathVariable Long id, @RequestBody prodottiEntity prodotto) {
       return prodottiService.updateProdotto(id, prodotto);
   }
   
   //ELIMINAZIONE
   @DeleteMapping("/eliminaprodotto/{id}")
   public ResponseEntity<String> deleteById(@PathVariable Long id) {
	   prodottiService.deleteProdottoById(id);
	   return ResponseEntity.ok("Eliminazione riuscita");
   }
   
   
   //JOIN TRA PRODOTTI E CATEGORIA
   @GetMapping("/prodotticoncategoria")
   public List<Object[]> getAllProdottiWithCategorie() {
       return prodottiService.getAllProdottiWithCategorie();
   }
   
   
      
   
   
   
}
