package com.alessandro.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alessandro.demo.entities.dipendentiEntity;
import com.alessandro.demo.service.dipendentiService;

@RestController
@RequestMapping("/api/dipendente")
public class dipendentiController {

	private final dipendentiService dipendentiService;
    
    public dipendentiController(dipendentiService dipendentiService)
    {
        this.dipendentiService = dipendentiService;
    }

    @GetMapping("/prova")
	public String prova()
	{
		return" prova";
	}
    
    //Lista DIPENDNETI
    @GetMapping("/listadipendenti")
    public List<dipendentiEntity> getDipendenti() {
        return this.dipendentiService.getDipendenti();
    }
    
   
    @PostMapping("/aggiungidipendente")
    public ResponseEntity<String> createDipendente(@RequestBody dipendentiEntity dipendente) {
        try {
            dipendentiEntity newDipendente = dipendentiService.createDipendente(dipendente);
            return ResponseEntity.ok("Dipendente creato con successo con ID: " + newDipendente.getId());
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Errore durante la creazione del dipendente: " + e.getMessage());
        }
    }
    
    //RICERCA PER ID
    @GetMapping("/byid/{id}")
    public Optional<dipendentiEntity> ricercaDipendentiPerID(@PathVariable Long id) {
        return dipendentiService.ricercaPerID(id);
    }

    //RICERCA PER NOME
    @GetMapping("/bynome/{nome}")
    public List<dipendentiEntity> ricercaDipendentiPerNome(@PathVariable String nome) {
        return dipendentiService.ricercaPerNome(nome);
    }
    
    //RICERCA PER COGNOME
    @GetMapping("/bycognome/{cognome}")
    public List<dipendentiEntity> ricercaDipendentiPerCognome(@PathVariable String cognome) {
        return dipendentiService.ricercaPerCognome(cognome);
    }
    
    //RICERCA PER EMAIL
    @GetMapping("/byemail/{email}")
    public List<dipendentiEntity> ricercaDipendentiPerEmail(@PathVariable String email) {
        return dipendentiService.ricercaPerEmail(email);
    }
    
    //RICERCA PER CODICEMANSIONE
    @GetMapping("/bycodicemansione/{codicemansione}")
    public List<dipendentiEntity> ricercaDipendentiPerCodiceMansione(@PathVariable Long codicemansione) {
        return dipendentiService.ricercaPerCodiceMansione(codicemansione);
    }
   
    //MODIFICA
    @PutMapping("/modifica/{id}")
    public dipendentiEntity updateDipendente(@PathVariable Long id, @RequestBody dipendentiEntity dipendente) {
        return dipendentiService.updateDipendente(id, dipendente);
    }
   
    
    //ELIMINAZIONE
    @DeleteMapping("/eliminadipendente/{id}")
    public ResponseEntity<String> deleteDipendente(@PathVariable Long id) {
        dipendentiService.deleteDipendente(id);
        return ResponseEntity.ok("Eliminazione riuscita");
    }

   
    //JOIN
    // LISTA DIPENDENTI CON MANSIONI
    @GetMapping("/dipendentiConMansioni")
    public List<Object[]> getDipendentiConMansioni() {
        return dipendentiService.getDipendentiConMansioni();
    }
	
    
    
    
}

