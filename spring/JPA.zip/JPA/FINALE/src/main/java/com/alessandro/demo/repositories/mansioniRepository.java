package com.alessandro.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.alessandro.demo.entities.mansioneEntity;

import jakarta.transaction.Transactional;


@Repository
public interface mansioniRepository extends JpaRepository<mansioneEntity, Long> {

	List<mansioneEntity> findByNome(String nome);
	List<mansioneEntity> findByDescrizioneContainingIgnoreCase(String descrizione);
	
  	void deleteById(Long id);
 
  	
  	
  	@Modifying
    @Transactional
    @Query("DELETE FROM dipendentiEntity d WHERE d.mansione.id = :id")
    void deleteMansioneAndDipendentiById(Long id);
  	
  	
}
