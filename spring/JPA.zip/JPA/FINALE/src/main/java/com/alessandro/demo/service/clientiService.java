package com.alessandro.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.alessandro.demo.entities.clientiEntity;
import com.alessandro.demo.repositories.clientiRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class clientiService {

	private final clientiRepository ICS;

	public clientiService(clientiRepository ICS)
	{
		this.ICS=ICS;
	}
	
	public List<clientiEntity> getClienti() {
	    return ICS.findAll();
	}
	
	public clientiEntity createCliente(clientiEntity cliente)
	{
		return this.ICS.save(cliente);
	}

	public Optional<clientiEntity> ricercaPerID(Long id) {
	    return ICS.findById(id);
	}
	
	public List<clientiEntity> ricercaPerNome(String nome) {
	    return ICS.findByNome(nome);
	}
	
	public List<clientiEntity> ricercaPerCognome(String cognome) {
	    return ICS.findByCognome(cognome);
	}
	
	public List<clientiEntity> ricercaPerEmail(String email) {
	    return ICS.findByEmail(email);
	}
	

	public List<clientiEntity> ricercaPerCodicePersonale(String codicepersonale) {
	    return this.ICS.findByCodicepersonale(codicepersonale);
	}

	

	//ELIMINAZIONE
	public void deleteCliente(Long id) {
	    this.ICS.deleteById(id);
	}

	//MODIFICA
		public clientiEntity updateCliente(Long id, clientiEntity cliente) {
	        // Controlla se il dipendente con l'id specificato esiste nel database
			clientiEntity existingCliente = this.ICS.findById(id)
	                .orElseThrow(() -> new EntityNotFoundException("Cliente non trovato"));

	        // Effettua le modifiche al dipendente esistente con i dati forniti
	        existingCliente.setNome(cliente.getNome());
	        existingCliente.setCognome(cliente.getCognome());
	        existingCliente.setEmail(cliente.getEmail());
	        existingCliente.setCodicepersonale(cliente.getCodicepersonale());
	        	
	        // Salva le modifiche nel database
	        return this.ICS.save(existingCliente);
	    }



	
	

	
	
	
	
	
	
	
	
	
	
	
}
