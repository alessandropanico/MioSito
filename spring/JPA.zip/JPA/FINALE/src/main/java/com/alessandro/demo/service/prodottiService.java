package com.alessandro.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.alessandro.demo.entities.categorieEntity;
import com.alessandro.demo.entities.prodottiEntity;
import com.alessandro.demo.repositories.prodottiRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class prodottiService {
private final prodottiRepository IPS;
	
	public prodottiService(prodottiRepository IPS)
	{
		this.IPS=IPS;
	}

	public List<prodottiEntity> getProdotti() {
		
		return this.IPS.findAll();
	}

	public prodottiEntity createProdotto(prodottiEntity prodotto) {

		return this.IPS.save(prodotto);
	}

	public Optional<prodottiEntity> ricercaPerID(Long id) {
		return this.IPS.findById(id);
	}

	public List<prodottiEntity> ricercaPerNomeProdotto(String nome) {
        return this.IPS.findByNome(nome);
    }

	public List<prodottiEntity> ricercaProdottoPerCategoria(Long categoria) {
		return this.IPS.findByCategoria(categoria);
	}

	public List<prodottiEntity> ricercaProdottoPerDescrizione(String descrizione) {
		return this.IPS.findByDescrizioneContainingIgnoreCase(descrizione);

	}

	public List<prodottiEntity> ricercaProdottoPerCosto(int costo) {
		return this.IPS.findByCosto(costo);
	}

	 
	//MODIFICA
	public prodottiEntity updateProdotto(Long id, prodottiEntity prodotto) {
		// Controlla se il dipendente con l'id specificato esiste nel database
		prodottiEntity existingProdotto = this.IPS.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("Prodotto non trovata"));

		// Effettua le modifiche al dipendente esistente con i dati forniti
		existingProdotto.setNome(prodotto.getNome());
		existingProdotto.setDescrizione(prodotto.getDescrizione());
		existingProdotto.setCosto(prodotto.getCosto());
		existingProdotto.setCodiceprodotto(prodotto.getCodiceprodotto());
		

		// Salva le modifiche nel database
		return this.IPS.save(existingProdotto);
	}

	

	public void deleteProdottoById(Long id) {
	    this.IPS.deleteById(id);
	}
	
	
	//JOIN LISTA
	 public List<Object[]> getAllProdottiWithCategorie() {
	        return this.IPS.findProdottiWithCategorie();
	    }
	
}
