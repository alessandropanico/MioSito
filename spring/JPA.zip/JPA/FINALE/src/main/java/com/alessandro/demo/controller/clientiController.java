package com.alessandro.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alessandro.demo.entities.clientiEntity;
import com.alessandro.demo.entities.dipendentiEntity;
import com.alessandro.demo.service.clientiService;


@RestController
@RequestMapping("/api/cliente")
public class clientiController {
	
	private final clientiService clientiService;

	public clientiController (clientiService clientiService)
	{
		this.clientiService=clientiService;
	}
	
	    @GetMapping("/listaclienti")
	    public List<clientiEntity> getClienti() {
	        return this.clientiService.getClienti();
	    }
	 
	    
	    
	    @PostMapping("/aggiungicliente")
	    public ResponseEntity<String> createCliente(@RequestBody clientiEntity cliente) {
	        try {
	        	clientiEntity newCliente = clientiService.createCliente(cliente);
	            return ResponseEntity.ok("Cliente creato con successo con ID: " + newCliente.getId());
	        } catch (Exception e) {
	            return ResponseEntity.badRequest().body("Errore durante la creazione del cliente: " + e.getMessage());
	        }
	    }

	    
	    //RICERCA PER ID
	    @GetMapping("/byid/{id}")
	    public Optional<clientiEntity> ricercaClientePerID(@PathVariable Long id) {
	        return clientiService.ricercaPerID(id);
	    }
	    
	    //RICERCA PER NOME
	    @GetMapping("/bynome/{nome}")
	    public List<clientiEntity> ricercaClientePerNomeCliente(@PathVariable String nome) {
	        return clientiService.ricercaPerNome(nome);
	    }
	    
	    //RICERCA PER COGNOME
	    @GetMapping("/bycognome/{cognome}")
	    public List<clientiEntity> ricercaClientePerCognomeCliente(@PathVariable String cognome) {
	        return clientiService.ricercaPerCognome(cognome);
	    }
	    
	    //RICERCA PER EMAIL
	    @GetMapping("/byemail/{email}")
	    public List<clientiEntity> ricercaClientePerEmailCliente(@PathVariable String email) {
	        return clientiService.ricercaPerEmail(email);
	    }
	   
	    
	    //RICERCA PER CODICEMANSIONE
	    @GetMapping("/bycodicepersonale/{codicepersonale}")
	    public List<clientiEntity> ricercaClientePerCodicePersonale(@PathVariable String codicepersonale) {
	        return clientiService.ricercaPerCodicePersonale(codicepersonale);
	    }
	   
	 
	    //MODIFICA
	    @PutMapping("/modifica/{id}")
	    public clientiEntity updateCliente(@PathVariable Long id, @RequestBody clientiEntity cliente) {
	        return clientiService.updateCliente(id, cliente);
	    }
	   
	    
	    //ELIMINAZIONE
	    @DeleteMapping("/eliminacliente/{id}")
	    public ResponseEntity<String> deleteCliente(@PathVariable Long id) {
	    	clientiService.deleteCliente(id);
	        return ResponseEntity.ok("Eliminazione riuscita");
	    }
}
