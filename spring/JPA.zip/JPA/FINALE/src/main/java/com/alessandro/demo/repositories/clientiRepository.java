package com.alessandro.demo.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.alessandro.demo.entities.clientiEntity;

@Repository
public interface clientiRepository extends JpaRepository<clientiEntity, Long> {

	List<clientiEntity> findByNome(String nome);

	List<clientiEntity> findByCognome(String cognome);

	List<clientiEntity> findByEmail(String email);

    List<clientiEntity> findByCodicepersonale(String codicepersonale);

	
  //ELIMINAZIONE
  	void deleteById(Long id);

}
