package com.alessandro.demo.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "dipendenti")
public class dipendentiEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "nome")
    private String nome;

    @Column(name = "cognome")
    private String cognome;

    @Column(name = "email")
    private String email;

    @Column(name = "codicemansione")
    private Long codicemansione;

    @ManyToOne
    @JoinColumn(name = "codicemansione", referencedColumnName = "id", insertable = false, updatable = false)
    private mansioneEntity mansione;

    public dipendentiEntity() {}

    // Getter e Setter di id
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    // Getter e Setter di nome
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

    // Getter e Setter di cognome
    public String getCognome() {
        return cognome;
    }
    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    // Getter e Setter di email
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    // Getter e Setter di codicemansione
    public Long getCodicemansione() {
        return codicemansione;
    }
    public void setCodicemansione(Long codicemansione) {
        this.codicemansione = codicemansione;
    }

    // Getter e Setter di mansione
    public mansioneEntity getMansione() {
        return mansione;
    }
    public void setMansione(mansioneEntity mansione) {
        this.mansione = mansione;
    }
}
