package com.alessandro.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.alessandro.demo.entities.categorieEntity;
import com.alessandro.demo.entities.mansioneEntity;
import com.alessandro.demo.repositories.mansioniRepository;

import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;

@Service
public class mansioniService {
private final mansioniRepository IMS;
	
	public mansioniService(mansioniRepository IMS)
	{
		this.IMS=IMS;
	}

	public List<mansioneEntity> getMansioni() 
	{
		return this.IMS.findAll();
	}

	public mansioneEntity createMansione(mansioneEntity mansione) {
		return this.IMS.save(mansione);
	}

	public Optional<mansioneEntity> ricercaMansionePerId(Long id) {
		return this.IMS.findById(id);
	}

	public List<mansioneEntity> ricercaMansioneNome(String nome) {
		return this.IMS.findByNome(nome);
	}

	public List<mansioneEntity> ricercaMansioneDescrizione(String descrizione) {
		return this.IMS.findByDescrizioneContainingIgnoreCase(descrizione);
	}


	//MODIFICA
	public mansioneEntity updateMansione(Long id, mansioneEntity mansione) {
		// Controlla se il dipendente con l'id specificato esiste nel database
		mansioneEntity existingMansione = this.IMS.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("Mansione non trovata"));

		// Effettua le modifiche al dipendente esistente con i dati forniti
		existingMansione.setNome(mansione.getNome());
		existingMansione.setDescrizione(mansione.getDescrizione());


		// Salva le modifiche nel database
		return this.IMS.save(existingMansione);
	}

	//ELIMAZIONE
	public void deleteMansioneById(Long id) {
	    this.IMS.deleteById(id);
	}
	
	
	
	//ELIMINAZIONE CON I DIPENDENTI
	 public void deleteMansioneDipendenteById(Long id) {
	        this.IMS.deleteMansioneAndDipendentiById(id);
	    }
	
	
	
}
