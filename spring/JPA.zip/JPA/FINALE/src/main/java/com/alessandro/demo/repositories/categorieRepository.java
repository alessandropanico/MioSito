package com.alessandro.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.alessandro.demo.entities.prodottiEntity;
import com.alessandro.demo.entities.categorieEntity;

import jakarta.transaction.Transactional;

@Repository
public interface categorieRepository extends JpaRepository<categorieEntity, Long>{

	List<categorieEntity> findByNome(String nome);
    List<categorieEntity> findByDescrizioneContainingIgnoreCase(String descrizione);

	
    //ELIMINAZIONE
  	void deleteById(Long id);
  	
  	
    @Modifying
    @Query("DELETE FROM prodottiEntity p WHERE p.categorie.id = :categoryId")
    void deleteProdottiByCategoryId(Long categoryId);
  
  	
}
