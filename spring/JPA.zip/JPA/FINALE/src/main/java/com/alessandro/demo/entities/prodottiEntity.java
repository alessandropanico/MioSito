package com.alessandro.demo.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="prodotti")
public class prodottiEntity {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long id;
	
	@Column(name="nome")
	private String nome;
	
	@Column(name="categoria")
	private Long categoria;
	
	@ManyToOne
    @JoinColumn(name = "categoria", referencedColumnName = "id", insertable = false, updatable = false)
    private categorieEntity categorie;
	

	
	@Column(name="descrizione")
	private String descrizione;
	
	@Column(name="costo")
	private int costo;
	
	@Column(name="codiceprodotto")
	private String codiceprodotto;
	
	
	
	
	public prodottiEntity() {}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Long getCategoria() {
		return categoria;
	}
	public void setCategoria(Long categoria) {
		this.categoria = categoria;
	}
	public String getDescrizione() {
		return descrizione;
	}
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	public int getCosto() {
		return costo;
	}
	public void setCosto(int costo) {
		this.costo = costo;
	}
	public String getCodiceprodotto() {
		return codiceprodotto;
	}
	public void setCodiceprodotto(String codiceprodotto) {
		this.codiceprodotto = codiceprodotto;
	}
}
