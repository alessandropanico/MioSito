package com.alessandro.demo.repositories;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.alessandro.demo.entities.dipendentiEntity;


@Repository
public interface dipendentiRepository extends JpaRepository<dipendentiEntity, Long> {

	//RICERCHE
	List<dipendentiEntity> findByNome(String nome);
	List<dipendentiEntity> findByCognome(String cognome);
	List<dipendentiEntity> findByEmail(String email);
	List<dipendentiEntity> findBycodicemansione(Long codicemansione);


	
	//ELIMINAZIONE
	void deleteById(Long id);

	
	//JOIN
	
	// Query con JOIN per visualizzare dipendenti con la loro mansione
    @Query("SELECT d, m FROM dipendentiEntity d JOIN mansioneEntity m ON d.codicemansione = m.id")
    List<Object[]> findDipendentiWithMansione();
	
	
}
