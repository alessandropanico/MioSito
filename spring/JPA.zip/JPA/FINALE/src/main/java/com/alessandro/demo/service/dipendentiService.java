package com.alessandro.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.alessandro.demo.entities.dipendentiEntity;
import com.alessandro.demo.repositories.dipendentiRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class dipendentiService {

private final dipendentiRepository IDS;
	
	public dipendentiService(dipendentiRepository IDS)
	{
		this.IDS=IDS;
	}
	
	public List<dipendentiEntity> getDipendenti() {
	    return IDS.findAll();
	}

	
	public dipendentiEntity createDipendente(dipendentiEntity dipendente) {
        return this.IDS.save(dipendente);
	
	}
	
	public Optional<dipendentiEntity> ricercaPerID(Long id) {
	    return IDS.findById(id);
	}
	
	public List<dipendentiEntity> ricercaPerNome(String nome) {
	    return IDS.findByNome(nome);
	}
	
	public List<dipendentiEntity> ricercaPerCognome(String cognome) {
	    return IDS.findByCognome(cognome);
	}
	
	public List<dipendentiEntity> ricercaPerEmail(String email) {
	    return IDS.findByEmail(email);
	}
	
	public List<dipendentiEntity> ricercaPerCodiceMansione(Long codicemansione) {
	    return this.IDS.findBycodicemansione(codicemansione);
	}
	

	


	//ELIMINAZIONE
	public void deleteDipendente(Long id) {
	    this.IDS.deleteById(id);
	}



	
	//MODIFICA
	public dipendentiEntity updateDipendente(Long id, dipendentiEntity dipendente) {
        // Controlla se il dipendente con l'id specificato esiste nel database
		dipendentiEntity existingDipendente = this.IDS.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Dipendente non trovato"));

        // Effettua le modifiche al dipendente esistente con i dati forniti
        existingDipendente.setNome(dipendente.getNome());
        existingDipendente.setCognome(dipendente.getCognome());
        existingDipendente.setEmail(dipendente.getEmail());
        existingDipendente.setCodicemansione(dipendente.getCodicemansione());

        // Salva le modifiche nel database
        return this.IDS.save(existingDipendente);
    }
	
	
	//---------------------------------
	//OPERAZIONI JOIN
	
	 public List<Object[]> getDipendentiConMansioni() {
	        return this.IDS.findDipendentiWithMansione();
	    }

	
	
	
	
	
	
	
	
	
	
	
	
	
}
