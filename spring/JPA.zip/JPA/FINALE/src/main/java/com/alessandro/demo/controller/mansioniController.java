package com.alessandro.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alessandro.demo.service.mansioniService;
import com.alessandro.demo.entities.categorieEntity;
import com.alessandro.demo.entities.mansioneEntity;

@RestController
@RequestMapping("/api/mansioni")
public class mansioniController {

	private final mansioniService mansioniService;

	public mansioniController(mansioniService mansioniService)
	{
		this.mansioniService=mansioniService;
	}


	//LISTA MANSIONI!
	@GetMapping("/listamansioni")
    public List<mansioneEntity> getMansioni() {
        return this.mansioniService.getMansioni();
    }
    
    //AGGIUNTA
    @PostMapping("/aggiungimansione")
    public ResponseEntity<String> createMansione(@RequestBody mansioneEntity mansione) {
        try {
        	mansioneEntity newMansione = mansioniService.createMansione(mansione);
            return ResponseEntity.ok("Mansione creato con successo con ID: " + newMansione.getId());
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Errore durante la creazione della categoria: " + e.getMessage());
        }
    }

    
    //RICERCA PER ID
    @GetMapping("/byid/{id}")
    public Optional <mansioneEntity> ricercaMansionePerId(@PathVariable Long id)
    {
    	return this.mansioniService.ricercaMansionePerId(id);
    }
    
    
    //RICERCA PE RNOME
    @GetMapping("/bynome/{nome}")
    public List<mansioneEntity> ricercaMansionePerNome(@PathVariable String nome)
    {
    	return this.mansioniService.ricercaMansioneNome(nome);
    }
    
    
    //RICERCA PER DESCRIZIONE
    @GetMapping("/bydescrizione/{descrizione}")
    public List<mansioneEntity> ricercaMansionePerDescrizione(@PathVariable String descrizione)
    {
    	return this.mansioniService.ricercaMansioneDescrizione(descrizione);
    }
    
    
    //MODIFICA
   @PutMapping("/modifica/{id}")
   public mansioneEntity updateMansione(@PathVariable Long id, @RequestBody mansioneEntity mansione)
   {
	   return this.mansioniService.updateMansione(id, mansione);
   }
    
   
   //ELIMINA
   @DeleteMapping("/elimina/{id}")
    public ResponseEntity<String> deleteMansioneByID(@PathVariable Long id)
    {
	    mansioniService.deleteMansioneById(id);
	    return ResponseEntity.ok("Eliminazione riusciuta");
    }
    
   
   //ELIMINA CON DIPENDENTI
   @DeleteMapping("/eliminacondipendenti/{id}")
   public ResponseEntity<Void> deleteMansioneDipendenteById(@PathVariable Long id) {
       mansioniService.deleteMansioneById(id);
       return new ResponseEntity<>(HttpStatus.NO_CONTENT);
   }
    
    
    
    
    
    
}
