package com.alessandro.demo.repositories;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.alessandro.demo.entities.prodottiEntity;


@Repository
public interface prodottiRepository extends JpaRepository<prodottiEntity, Long>{

    List<prodottiEntity> findByNome(String nome);
	List<prodottiEntity> findByCategoria(Long categoria);
	List<prodottiEntity> findByDescrizioneContainingIgnoreCase(String descrizione);
	List<prodottiEntity> findByCosto(int costo);
	
  	void deleteById(Long id);

	
  	//JOIN
  	@Query("SELECT p, c FROM prodottiEntity p JOIN categorieEntity c ON p.categoria = c.id")
  	List<Object[]> findProdottiWithCategorie();

}
