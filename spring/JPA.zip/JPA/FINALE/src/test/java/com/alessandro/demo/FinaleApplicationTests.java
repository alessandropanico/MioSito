package com.alessandro.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinaleApplicationTests {

	@Test
	void contextLoads() {
	}

}
