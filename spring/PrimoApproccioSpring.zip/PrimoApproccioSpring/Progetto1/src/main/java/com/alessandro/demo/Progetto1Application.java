package com.alessandro.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Progetto1Application {

	public static void main(String[] args) {
		SpringApplication.run(Progetto1Application.class, args);
	}

}
